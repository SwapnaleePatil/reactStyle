import React, { Component } from 'react';
//import {Route,BrowserRouter,NavLink,Prompt,Switch} from 'react-router-dom'
import './table.css';

class Table extends React.Component
{
    render()
    {
        return(
<div className="table">
            <div className="container">
                <form >
                    <div className="row">
                        <div className="col-25">
                            <label>Full Name</label>
                        </div>
                        <div className="col-75">
                            <input type="text" id="fname" name="firstname" placeholder="Enter Your Name"/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label>Email</label>
                        </div>
                        <div className="col-75">
                            <input type="email" id="lname" name="lastname" placeholder="Enter Your Email"/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label>Password</label>
                        </div>
                        <div className="col-75">
                            <input type="password" id="fname" name="firstname" placeholder="Enter Your Secure Password"/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label>Phone No</label>
                        </div>
                        <div className="col-75">
                            <input type="number" id="lname" name="lastname" placeholder="Enter Number"/>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label>Gender</label>
                        </div>
                        <div className="col-75">
                            <div className="row">
                            <input type="radio" name="r1" id="r1"/><h5 align="left">Male</h5>
                                <input type="radio" name="r1" id="r1"/><h5 align="left">Female</h5>

                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">
                            <label>City</label>
                        </div>
                        <div className="col-75">
                            <select id="country" name="country">
                                <option>--Select--</option>
                                <option value="vyara">Vyara</option>
                                <option value="surat">Surat</option>
                                <option value="mumbai">Mumbai</option>
                            </select>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-25">

                        </div>
                        <div className="col-75">
                            <div className="row">
                            <input type="checkbox" id="lname" name="lastname" /><h5 align="left"> I Agree</h5>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <input type="submit" value="Submit"/>
                    </div>
                   </form>
            </div>
</div>
        )
    }
}

export default Table;